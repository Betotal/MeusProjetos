using System.Data.SqlClient;

namespace SaloonConsoleApp.Infrastructure.Data
{
    public static class DbConnectionFactory
    {
        private static readonly string _connectionString =
            @"Server=(localdb)\MSSQLLocalDB;Database=SaloonDB;Trusted_Connection=True;";

        public static SqlConnection CreateConnection()
        {
            return new SqlConnection(_connectionString);
        }
    }
}

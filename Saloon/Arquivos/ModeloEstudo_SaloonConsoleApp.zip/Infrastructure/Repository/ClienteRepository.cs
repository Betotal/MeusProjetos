using System.Collections.Generic;
using System.Data.SqlClient;
using SaloonConsoleApp.Domain.Entities;
using SaloonConsoleApp.Domain.Interfaces;
using SaloonConsoleApp.Infrastructure.Data;

namespace SaloonConsoleApp.Infrastructure.Repository
{
    public class ClienteRepository : IClienteRepository
    {
        public Cliente ObterPorId(int id)
        {
            using var connection = DbConnectionFactory.CreateConnection();
            connection.Open();

            var cmd = new SqlCommand("SELECT Id, Nome, Telefone FROM Clientes WHERE Id = @Id", connection);
            cmd.Parameters.AddWithValue("@Id", id);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                return new Cliente
                {
                    Id = reader.GetInt32(0),
                    Nome = reader.GetString(1),
                    Telefone = reader.GetString(2)
                };
            }
            return null;
        }

        public IEnumerable<Cliente> ObterTodos()
        {
            var clientes = new List<Cliente>();
            using var connection = DbConnectionFactory.CreateConnection();
            connection.Open();

            var cmd = new SqlCommand("SELECT Id, Nome, Telefone FROM Clientes", connection);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                clientes.Add(new Cliente
                {
                    Id = reader.GetInt32(0),
                    Nome = reader.GetString(1),
                    Telefone = reader.GetString(2)
                });
            }
            return clientes;
        }

        public void Adicionar(Cliente cliente)
        {
            using var connection = DbConnectionFactory.CreateConnection();
            connection.Open();

            var cmd = new SqlCommand("INSERT INTO Clientes (Nome, Telefone) VALUES (@Nome, @Telefone)", connection);
            cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
            cmd.Parameters.AddWithValue("@Telefone", cliente.Telefone);
            cmd.ExecuteNonQuery();
        }

        public void Atualizar(Cliente cliente)
        {
            using var connection = DbConnectionFactory.CreateConnection();
            connection.Open();

            var cmd = new SqlCommand("UPDATE Clientes SET Nome=@Nome, Telefone=@Telefone WHERE Id=@Id", connection);
            cmd.Parameters.AddWithValue("@Id", cliente.Id);
            cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
            cmd.Parameters.AddWithValue("@Telefone", cliente.Telefone);
            cmd.ExecuteNonQuery();
        }

        public void Remover(int id)
        {
            using var connection = DbConnectionFactory.CreateConnection();
            connection.Open();

            var cmd = new SqlCommand("DELETE FROM Clientes WHERE Id=@Id", connection);
            cmd.Parameters.AddWithValue("@Id", id);
            cmd.ExecuteNonQuery();
        }
    }
}

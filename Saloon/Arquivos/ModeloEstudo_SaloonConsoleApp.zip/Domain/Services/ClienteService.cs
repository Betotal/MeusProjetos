using SaloonConsoleApp.Domain.Entities;
using SaloonConsoleApp.Domain.Interfaces;
using System.Collections.Generic;

namespace SaloonConsoleApp.Domain.Services
{
    public class ClienteService
    {
        private readonly IClienteRepository _clienteRepository;

        public ClienteService(IClienteRepository clienteRepository)
        {
            _clienteRepository = clienteRepository;
        }

        public IEnumerable<Cliente> ListarClientes() => _clienteRepository.ObterTodos();

        public Cliente ObterCliente(int id) => _clienteRepository.ObterPorId(id);

        public void CriarCliente(string nome, string telefone)
        {
            var cliente = new Cliente { Nome = nome, Telefone = telefone };
            _clienteRepository.Adicionar(cliente);
        }

        public void AtualizarCliente(int id, string nome, string telefone)
        {
            var cliente = new Cliente { Id = id, Nome = nome, Telefone = telefone };
            _clienteRepository.Atualizar(cliente);
        }

        public void RemoverCliente(int id) => _clienteRepository.Remover(id);
    }
}

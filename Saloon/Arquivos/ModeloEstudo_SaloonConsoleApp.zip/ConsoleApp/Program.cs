using System;
using SaloonConsoleApp.Domain.Services;
using SaloonConsoleApp.Infrastructure.Repository;

namespace SaloonConsoleApp.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var repo = new ClienteRepository();
            var service = new ClienteService(repo);

            Console.WriteLine("=== CRUD de Clientes (SQLLocalDB / ADO.NET) ===");

            while (true)
            {
                Console.WriteLine("\n1 - Listar Clientes");
                Console.WriteLine("2 - Adicionar Cliente");
                Console.WriteLine("3 - Atualizar Cliente");
                Console.WriteLine("4 - Remover Cliente");
                Console.WriteLine("0 - Sair");
                Console.Write("Escolha: ");
                var opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        foreach (var c in service.ListarClientes())
                            Console.WriteLine($"{c.Id} - {c.Nome} ({c.Telefone})");
                        break;

                    case "2":
                        Console.Write("Nome: ");
                        var nome = Console.ReadLine();
                        Console.Write("Telefone: ");
                        var telefone = Console.ReadLine();
                        service.CriarCliente(nome, telefone);
                        Console.WriteLine("Cliente adicionado!");
                        break;

                    case "3":
                        Console.Write("ID do cliente: ");
                        var idAtt = int.Parse(Console.ReadLine());
                        Console.Write("Novo Nome: ");
                        var novoNome = Console.ReadLine();
                        Console.Write("Novo Telefone: ");
                        var novoTelefone = Console.ReadLine();
                        service.AtualizarCliente(idAtt, novoNome, novoTelefone);
                        Console.WriteLine("Cliente atualizado!");
                        break;

                    case "4":
                        Console.Write("ID do cliente: ");
                        var idDel = int.Parse(Console.ReadLine());
                        service.RemoverCliente(idDel);
                        Console.WriteLine("Cliente removido!");
                        break;

                    case "0":
                        return;
                }
            }
        }
    }
}

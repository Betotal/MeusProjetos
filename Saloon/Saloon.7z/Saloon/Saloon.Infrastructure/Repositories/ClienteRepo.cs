using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Saloon.Domain.Entities;
using Saloon.Domain.Interfaces;

namespace Saloon.Infrastructure.Repositories
{
    public class ClienteRepo : IClienteRepo
    {
        public ClienteRepo()
        {
//            var _clienteRepo = new ClienteRepo();
        }
        bool IClienteRepo.Atualizar(ClienteEnty cliente)
        {
            using (var connection = new SqlConnection(Global.StringConnection))
            {
                connection.Open();
                var cmd = new SqlCommand($"UPDATE Cliente Set Nome = '{cliente.Nome}', Telefone = '{cliente.Telefone}', Aniversario = '{cliente.Aniversario}'", connection);
//                var cmd = new SqlCommand("UPDATE Cliente Set Nome = @Nome, Telefone = @Telefone, Aniversario = @Aniversario", connection);
//                cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
//                cmd.Parameters.AddWithValue("@Telefone", cliente.Telefone);
//                cmd.Parameters.AddWithValue("@Aniversario", cliente.Aniversario);
                cmd.ExecuteNonQuery();
                return true;
            }

        }

        int IClienteRepo.Cadastrar(ClienteEnty cliente, int idUsuario)
        {
            using (var connection = new SqlConnection(Global.StringConnection))
            {
                connection.Open();
                var cmd = new SqlCommand($"INSERT INTO CLIENTE (IdUsuario, Nome, Telefone, Aniversario) VALUES ('{idUsuario}', '{cliente.Nome}', '{cliente.Telefone}','{cliente.Aniversario}')", connection);
//                var cmd = new SqlCommand("INSERT INTO CLIENTE (IdUsuario, Nome, Telefone, Aniversario) VALUES (@IdUsuario, @Nome, @Telefone, @Aniversario)", connection);
//                cmd.Parameters.AddWithValue("@IdUsuario", IUsuarioRepo.Cadastrar(UsuarioEnty usuario));
//                cmd.Parameters.AddWithValue("@Nome", cliente.Nome);
//                cmd.Parameters.AddWithValue("@Telefone", cliente.Telefone);
//                cmd.Parameters.AddWithValue("@Aniversario", cliente.Aniversario);
//                cmd.Parameters.AddWithValue("@IdUsuario", idUsuario);
                cmd.ExecuteNonQuery();
                cmd = new SqlCommand($"SELECT ID FROM CLIENTE WHERE Nome = '{cliente.Nome}' and Telefone = '{cliente.Telefone}' and Aniversario = '{cliente.Aniversario}'", connection);
                
                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return reader.GetInt32(0);
                } else return 0;
            }
        }

        ClienteEnty? IClienteRepo.ConsultarPorId(int id)
        {
            using (var connection = new SqlConnection(Global.StringConnection))
            {
                connection.Open();
                var cmd = new SqlCommand($"SELECT * FROM CLIENTE Where ID = {id}", connection);
//                cmd.Parameters.AddWithValue("@Id", id);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new ClienteEnty
                    {
                        ID = reader.GetInt32(0),
                        IdUsuario = reader.GetInt32(1),
                        Nome = reader.GetString(2),
                        Telefone = reader.GetString(3),
                        Aniversario = DateOnly.TryParseExact(reader.GetString(4), "dd/MM/yyyy", out DateOnly result) ? result : default
                    };
                }
                return null;
            }
        }
        ClienteEnty? IClienteRepo.ConsultarPorNome(string nome)
        {
            using (var connection = new SqlConnection(Global.StringConnection))
            {
                connection.Open();
                var cmd = new SqlCommand($"SELECT * FROM CLIENTE Where Nome = '{nome}'", connection);
//                cmd.Parameters.AddWithValue("@Nome", nome);

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new ClienteEnty
                    {
                        ID = reader.GetInt32(0),
                        Nome = reader.GetString(1),
                        Telefone = reader.GetString(2),
                        Aniversario = DateOnly.FromDateTime(reader.GetDateTime(3)),
                        IdUsuario = reader.GetInt32(4)
                    };
                }
                return null;
            }
        }

        bool IClienteRepo.Deletar(int id)
        {
            using (var connection = new SqlConnection(Global.StringConnection))
            {
                connection.Open();
                var cmd = new SqlCommand($"DELETE FROM CLIENTE Where ID = {id}", connection);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
                return true;
            }
        }

        List<ClienteEnty> IClienteRepo.Listar()
        {
            throw new NotImplementedException();
        }

        List<ClienteEnty> IClienteRepo.ListarPorNome(string nome)
        {
            throw new NotImplementedException();
        }
    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Identity.Client;

namespace Saloon.ConsoleApp.InterfaceUsuario
{
    public class Tela
    {
        public static void LimpaTela()
        {
            Console.Clear();
            Moldura();  
            NomeSalao();
        }

        public static void Moldura()
        {
            for (int i = 1; i <= 25; i++)
            {
                if (i == 1 ){
                    for (int j = 1; j <= 90; j++)
                    {
                        Console.SetCursorPosition(j, 1);
                        Console.Write("*");
                        Console.SetCursorPosition(j,25);
                        Console.Write("*");
                    }
 
                }
                Console.SetCursorPosition(1,i);
                Console.Write("*");
                Console.SetCursorPosition(90,i);
                Console.Write("*");
            }
        }

        public static void NomeSalao()
        {
            Console.SetCursorPosition(20,3);
            Console.Write("*************************************");
            Console.SetCursorPosition(20,4);
            Console.Write("***  Bem Vindo ao Sistema Saloon  ***");
            Console.SetCursorPosition(20,5);
            Console.Write("*************************************");
        }

        public static void LimpaMenu2(string Menu1){
            Moldura2(Menu1);
        }

        public static void Moldura2(string Menu1)
        {
            for (int i = 9; i <= 22; i++)
            {
                if (i == 9 ){
                    for (int j = 30; j <= 61; j++)
                    {
                        Console.SetCursorPosition(j, 9);
                        Console.Write("*");
                        Console.SetCursorPosition(j, 22);
                        Console.Write("*");
                    } 
                }

                if (i > 9 && i < 22)
                {
                    Console.SetCursorPosition(31, i);
                    Console.Write("                            ");
                }
                if (i == 10)
                {
                    Console.SetCursorPosition(31, i);
                    switch (Menu1)
                    {
                        case "1":Console.Write(" *    Cadastro de Clientes   *");
                            break;
                        case "2":Console.Write(" * Cadastro de Profissionais *");
                            break;
                        case "3":Console.Write(" *    Cadastro de Serviços   *");
                            break;
                        case "4":Console.Write(" *    Cadastro de Horarios   *");
                            break;
                        case "5":Console.Write(" *     Cadastro de Cargos    *");
                            break;
                        case "6":Console.Write(" *   Cadastro de Descontos   *");
                            break;
                        case "7":Console.Write(" *   Cadastro de Promoçoes   *");
                            break;
                        case "8":Console.Write(" *        Agendamento        *");
                            break;
                    }                    
                }
                if (i == 11)
                {
                    Console.SetCursorPosition(31, i);
                    Console.Write("******************************");
                }
                Console.SetCursorPosition(30, i);
                Console.Write(" *");
                Console.SetCursorPosition(61,i);
                Console.Write("*");                
            }
        }

        public static void Moldura3()
        {
            for (int i = 12; i <= 24; i++)
            {
                if (i == 12 ){
                    for (int j = 50; j <= 89; j++)
                    {
                        Console.SetCursorPosition(j, 12);
                        Console.Write("/");
                        Console.SetCursorPosition(j, 24);
                        Console.Write("/");
                    } 
                }
                

                if (i > 12 && i < 24)
                {
                    Console.SetCursorPosition(51, i);
                    Console.Write("                                ");
                }
                Console.SetCursorPosition(50, i);
                Console.Write(" /");
                Console.SetCursorPosition(89,i);
                Console.Write("/");                
            }
        }

    }
}
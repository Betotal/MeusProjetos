﻿namespace Saloon.Domain;

public class Class1
{

}

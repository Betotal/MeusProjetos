using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Saloon.Domain.Entities
{
    public class ProfissionalServicoEnty
    {
        public int ID { get; set; }
        public int IdProfissional { get; set; }
        public int IdServico { get; set; } 
    }
}
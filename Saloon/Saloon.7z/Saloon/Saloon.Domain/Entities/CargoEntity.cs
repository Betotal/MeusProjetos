using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Saloon.Domain.Entities
{
    public class CargoEnty
    {
        public int ID { get; set; }
        public required string Nome { get; set; }
    }
}
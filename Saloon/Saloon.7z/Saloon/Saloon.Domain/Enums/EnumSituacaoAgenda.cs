namespace Saloon.Domain.Enums
{
    public enum EnumSituacaoAgenda
    {
        EmAndamentento = 1,
        Finalizado, 
        Cancelado,
        NaoCompareceu, 
        Reagendado
    }
}
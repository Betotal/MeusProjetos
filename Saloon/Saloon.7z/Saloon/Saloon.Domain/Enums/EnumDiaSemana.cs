namespace Saloon.Domain.Enums
{
    public enum EnumDiaSemana
    {
        Domingo = 1,
        Segunda,
        Terca,
        Quarta,
        Quinta,
        Sexta,
        Sabado
    }
}
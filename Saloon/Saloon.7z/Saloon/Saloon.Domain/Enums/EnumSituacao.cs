namespace Saloon.Domain.Enums;

public enum EnumSituacao
{
    Ativo = 1,
    Inativo
    }

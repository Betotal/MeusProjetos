namespace Saloon.Domain.Enums
{
    public enum EnumQuemPaga
    {
        Salao = 1,
        Profissional,
        Dividido
   }
}
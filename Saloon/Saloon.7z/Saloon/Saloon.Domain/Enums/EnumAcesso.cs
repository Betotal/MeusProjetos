namespace Saloon.Domain.Enums
{
    public enum EnumAcesso
    {
        Administrador = 0,
        Cliente,
        Profissional,
        ProfissionalAdmin,
        Recepcionista,
        Financeiro
    }
}
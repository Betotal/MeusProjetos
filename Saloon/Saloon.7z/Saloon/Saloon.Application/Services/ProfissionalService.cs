
namespace Saloon.Application.Services
{
    public class ProfissionalServ
    {

    }
}
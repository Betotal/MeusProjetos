
namespace Saloon.Application.DTOs
{
    public class UsuarioDto
    {

    }
}

﻿namespace Saloon.Application;

public class Class1
{

}
